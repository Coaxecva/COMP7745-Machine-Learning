import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.Logistic;
import weka.classifiers.trees.*;
import weka.core.Instances;
import weka.core.converters.CSVLoader;

import java.io.*;

import weka.filters.Filter;
import weka.filters.supervised.attribute.Discretize;
import weka.filters.supervised.instance.SpreadSubsample;
import weka.filters.unsupervised.attribute.NumericToNominal;

import java.util.Random;
 
public class WekaRun {
	public static BufferedReader readDataFile(String filename) {
		BufferedReader inputReader = null;
 
		try {
			inputReader = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException ex) {
			System.err.println("File not found: " + filename);
		}
 
		return inputReader;
	}

	public static Instances load_csv(String filename) {
		Instances data=null;
		try {
		BufferedReader datafile = readDataFile(filename);
		CSVLoader loader = new CSVLoader();
		loader.setSource(new File(filename));
		data = loader.getDataSet();
		data.setClassIndex(data.numAttributes() - 1);
		} catch(Exception e)
		{}
		return data;
	}

	
	public static void main(String[] args) throws Exception {
		Instances data = load_csv(args[0]);

		Classifier cls = new Logistic();
		Evaluation eval = new Evaluation(data);
		Random rand = new Random(1);  // using seed = 1
		int folds = 5;
		eval.crossValidateModel(cls, data, folds, rand);
		//System.out.println(eval.toClassDetailsString());
	}
}
